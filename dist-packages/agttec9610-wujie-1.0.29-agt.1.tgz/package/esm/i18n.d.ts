/**
 * i18n para los mensajes internos de wujie (warn/error).
 *
 * Las claves del diccionario son los strings originales en chino tal como se
 * definen en `constant.ts` (más el mensaje inline en inglés de `iframe.ts`).
 * Mantener `constant.ts` y los call-sites intactos minimiza conflictos al
 * rebasar con upstream (Tencent/wujie).
 *
 * Uso:
 *   import { setLocale } from "@agttec9610/wujie";
 *   setLocale("es");
 */
export type Locale = "zh-CN" | "es" | "en" | (string & {});
type Dict = Record<string, string>;
export declare function setLocale(locale: Locale, customMessages?: Dict): void;
export declare function getLocale(): Locale;
export declare function t(msg: string, vars?: Record<string, string | number>): string;
export {};
